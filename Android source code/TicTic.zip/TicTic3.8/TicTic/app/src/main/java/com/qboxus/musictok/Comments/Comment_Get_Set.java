package com.qboxus.musictok.Comments;

/**
 * Created by AQEEL on 3/5/2019.
 */

public class Comment_Get_Set {
    public String video_id,fb_id,first_name,last_name,profile_pic,comments,created;

}
