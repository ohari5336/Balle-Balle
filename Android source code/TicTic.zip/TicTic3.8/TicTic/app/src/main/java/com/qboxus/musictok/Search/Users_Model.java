package com.qboxus.musictok.Search;

public class Users_Model {

    public String fb_id,username,first_name,last_name,gender,profile_pic,signup_type,videos;

}
