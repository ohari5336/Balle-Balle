package com.qboxus.musictok.SimpleClasses;

import android.view.View;

public interface Adapter_Click_Listener {
    void onItemClick(View view, int pos, Object object);
}
