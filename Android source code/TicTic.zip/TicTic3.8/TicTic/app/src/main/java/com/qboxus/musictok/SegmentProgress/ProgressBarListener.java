package com.qboxus.musictok.SegmentProgress;

/**
 * Created by AQEEL on 3/26/2019.
 */

public interface  ProgressBarListener {

    void TimeinMill(long mills);
}
