package com.qboxus.musictok.Following;

public class Following_Get_Set {

   public String fb_id,username,first_name,last_name,gender,profile_pic,bio;

   public String follow,follow_status_button;

    public boolean is_show_follow_unfollow_btn=true;
}
