package com.qboxus.musictok.SimpleClasses;

public interface Fragment_Data_Send {

    void onDataSent(String yourData);
}
