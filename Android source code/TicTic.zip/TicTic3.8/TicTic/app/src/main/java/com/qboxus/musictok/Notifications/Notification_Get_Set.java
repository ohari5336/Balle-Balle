package com.qboxus.musictok.Notifications;

/**
 * Created by AQEEL on 2/25/2019.
 */

public class Notification_Get_Set {

    public String fb_id,username,first_name,last_name,profile_pic,effected_fb_id,type;
    public String id,video,thum,gif,created;


}
