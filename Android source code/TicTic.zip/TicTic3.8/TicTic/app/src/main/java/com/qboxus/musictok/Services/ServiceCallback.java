package com.qboxus.musictok.Services;

/**
 * Created by AQEEL on 3/22/2019.
 */

public interface ServiceCallback {
    void ShowResponce(String responce);
}