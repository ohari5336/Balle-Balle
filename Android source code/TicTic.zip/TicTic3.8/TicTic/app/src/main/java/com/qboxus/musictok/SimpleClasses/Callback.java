package com.qboxus.musictok.SimpleClasses;

/**
 * Created by AQEEL on 4/4/2019.
 */

public interface Callback {

    void Responce(String resp);
}
