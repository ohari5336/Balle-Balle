package com.qboxus.musictok.Video_Recording.GalleryVideos;

public class GalleryVideo_Get_Set {
    String video_path,video_time;
    long video_duration_ms;
}
